<?php
$dadosPdo = [
    'dns' => 'mysql:host=sql202.epizy.com;dbname=epiz_33185930_aula_46;charset=utf8',
    'usuario' => 'epiz_33185930',
    'senha' => 'incluirsenha'
];?>