<?php
$dadosPdo = [
    'dns' => 'mysql:host=localhost; dbname=aula_44',
    'usuario' => 'root',
    'senha' => ''
];