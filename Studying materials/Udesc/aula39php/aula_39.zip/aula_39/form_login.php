<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/83b17fe985.js" crossorigin="anonymous"></script>
        <link rel="icon" href="img/favicon-32x32.png" sizes="32x32" type="image/png">
        <link href="css/signin.css" rel="stylesheet">
        
    </head>
    <body class="text-center">
        <main class="form-signin w-100 m-auto">
            <form>
                <i class="fa-5x fa-solid fa-cloud-arrow-up"></i>
                <h1 class="h3 mb-3 fw-normal">Área restrita</h1>

                <div class="form-floating">
                    <input type="email" class="form-control" name="email" id="email" placeholder="nome@examplo.com" maxlength="50">
                    <label for="email">E-mail</label>
                </div>
                <div class="form-floating">
                    <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha" maxlength="50">
                    <label for="senha">Senha</label>
                </div>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Entrar</button>
            </form>
        </main>
    </body>
</html>
