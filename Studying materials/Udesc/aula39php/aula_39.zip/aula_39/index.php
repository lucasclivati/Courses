<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Aula 39</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  <link rel="icon" href="img/favicon-32x32.png" sizes="32x32" type="image/png">
  <script src="https://kit.fontawesome.com/83b17fe985.js" crossorigin="anonymous"></script>
  <link href="css/signin.css" rel="stylesheet">
</head>
<body>
  <main class="d-flex flex-nowrap">
    <h1 class="visually-hidden">Aula 39</h1>
    <div class="d-flex flex-column flex-shrink-0 p-3 text-bg-dark" style="width: 280px;">
      <a href="index.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
        <span class="fs-4"><i class="fa-solid fa-cloud-arrow-up"></i> Aula 39</span>
      </a>
      <hr>
      <ul class="nav nav-pills flex-column mb-auto">
          <li class="nav-item">
            <a href="#" class="nav-link active" aria-current="page">
              <i class="fa-solid fa-house"></i> Página Inicial
            </a>
          </li>
          <li>
            <a href="#" class="nav-link text-white">
              <i class="fa-solid fa-gauge-high"></i> Dashboard
            </a>
          </li>
          <li>
            <a href="#" class="nav-link text-white">
              <i class="fa-solid fa-table"></i> Vendas
            </a>
          </li>
          <li>
            <a href="#" class="nav-link text-white">
              <i class="fa-solid fa-table-list"></i> Produtos
            </a>
          </li>
          <li>
            <a href="#" class="nav-link text-white">
              <i class="fa-solid fa-users"></i> Clientes
            </a>
          </li>
        </ul>
        <hr>
        <div class="dropdown">
          <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="img/favicon-32x32.png" alt="" width="48" height="48" class="rounded-circle me-2">
            <strong>NOME DO USUARIO</strong>
          </a>
          <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
            <li><a class="dropdown-item" href="#">Novo projeto</a></li>
            <li><a class="dropdown-item" href="#">Configurações</a></li>
            <li><a class="dropdown-item" href="#">Perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="logout.php">Sair</a></li>
        </ul>
      </div>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>
